


import DataAccessObjects.FahrzeugDAO;
import DataAccessObjects.KundenDAO;
import Tables.Fahrzeug;
import Tables.Kunde;

import java.util.List;

/**
 * Created by Fabian on 27.06.15.
 */
public class main {



    public static void main(String [] args) {
      //  System.out.println("Hello World");


//        KundenDAO k = new KundenDAO();
//        List<Kunde> test = k.readAllKunden();
//        for(int i = 0; i< test.size(); i++){
//            System.out.println(test.get(i).getName());
//        }


    }

}
